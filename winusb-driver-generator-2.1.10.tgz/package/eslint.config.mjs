import { defineConfig } from "eslint/config";
import globals from "globals";
import path from "node:path";
import { fileURLToPath } from "node:url";
import js from "@eslint/js";
import { FlatCompat } from "@eslint/eslintrc";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const compat = new FlatCompat({
    baseDirectory: __dirname,
    recommendedConfig: js.configs.recommended,
    allConfig: js.configs.all
});

export default defineConfig([{
    extends: compat.extends("eslint:recommended"),

    languageOptions: {
        globals: {
            ...globals.browser,
            ...globals.commonjs,
            ...globals.node,
            ...globals.mocha,
        },
    },

    rules: {
        "comma-dangle": ["error", "never"],
        "no-cond-assign": ["error"],
        "no-console": ["off"],
        "no-constant-condition": ["error"],
        "no-control-regex": ["error"],
        "no-debugger": ["error"],
        "no-dupe-args": ["error"],
        "no-dupe-keys": ["error"],
        "no-duplicate-case": ["error"],
        "no-empty": ["error"],
        "no-empty-character-class": ["error"],
        "no-ex-assign": ["error"],
        "no-extra-boolean-cast": ["error"],
        "no-extra-parens": ["error"],
        "no-extra-semi": ["error"],
        "no-func-assign": ["error"],
        "no-inner-declarations": ["error", "both"],
        "no-invalid-regexp": ["error"],
        "no-irregular-whitespace": ["error"],
        "no-negated-in-lhs": ["error"],
        "no-obj-calls": ["error"],
        "no-prototype-builtins": ["error"],
        "no-regex-spaces": ["error"],
        "no-sparse-arrays": ["error"],
        "no-unexpected-multiline": ["error"],
        "no-unreachable": ["error"],
        "no-unsafe-finally": ["error"],
        "use-isnan": ["error"],
        "valid-typeof": ["error"],
        "accessor-pairs": ["error"],
        "array-callback-return": ["error"],
        "block-scoped-var": ["error"],
        complexity: ["off"],
        curly: ["error"],
        "default-case": ["error"],
        "dot-location": ["error", "property"],
        "dot-notation": ["error"],
        eqeqeq: ["error"],
        "guard-for-in": ["error"],
        "no-alert": ["error"],
        "no-caller": ["error"],
        "no-case-declarations": ["error"],
        "no-div-regex": ["error"],
        "no-else-return": ["error"],
        "no-empty-function": ["error"],
        "no-empty-pattern": ["error"],
        "no-eq-null": ["error"],
        "no-eval": ["error"],
        "no-extend-native": ["error"],
        "no-extra-bind": ["error"],
        "no-extra-label": ["error"],
        "no-fallthrough": ["error"],
        "no-floating-decimal": ["error"],
        "no-implicit-coercion": ["error"],
        "no-implicit-globals": ["error"],
        "no-implied-eval": ["error"],
        "no-iterator": ["error"],
        "no-labels": ["error"],
        "no-lone-blocks": ["error"],
        "no-loop-func": ["error"],
        "no-multi-spaces": ["error"],
        "no-multi-str": ["error"],
        "no-native-reassign": ["error"],
        "no-new": ["error"],
        "no-new-func": ["error"],
        "no-new-wrappers": ["error"],
        "no-octal": ["error"],
        "no-octal-escape": ["error"],
        "no-proto": ["error"],
        "no-redeclare": ["error"],
        "no-return-assign": ["error"],
        "no-script-url": ["error"],
        "no-self-assign": ["error"],
        "no-self-compare": ["error"],
        "no-sequences": ["error"],
        "no-throw-literal": ["error"],
        "no-unmodified-loop-condition": ["error"],
        "no-unused-labels": ["error"],
        "no-useless-call": ["error"],
        "no-useless-concat": ["error"],
        "no-useless-escape": ["error"],
        "no-void": ["error"],
        "no-warning-comments": ["off"],
        "no-with": ["error"],
        radix: ["error"],
        "vars-on-top": ["off"],
        "wrap-iife": ["error", "outside"],
        yoda: ["error"],
        strict: ["error", "global"],
        "no-catch-shadow": ["error"],
        "no-delete-var": ["error"],
        "no-label-var": ["error"],
        "no-shadow": ["error"],
        "no-shadow-restricted-names": ["error"],
        "no-undef": ["error"],
        "no-undef-init": ["error"],
        "no-unused-vars": ["error"],
        "no-use-before-define": ["error"],
        "callback-return": ["error"],
        "global-require": ["off"],
        "handle-callback-err": ["error"],
        "no-mixed-requires": ["error"],
        "no-new-require": ["error"],
        "no-path-concat": ["error"],
        "no-process-env": ["off"],
        "no-process-exit": ["off"],
        "no-sync": ["off"],
        "array-bracket-spacing": ["error", "always"],
        "block-spacing": ["error"],
        "brace-style": ["error", "1tbs"],
        camelcase: ["error"],

        "comma-spacing": ["error", {
            before: false,
            after: true,
        }],

        "comma-style": ["error", "last"],
        "computed-property-spacing": ["error", "never"],
        "consistent-this": ["error", "self"],
        "eol-last": ["error"],
        "func-names": ["error", "never"],
        "func-style": ["error", "expression"],
        "id-blacklist": ["error"],

        indent: ["error", 2, {
            SwitchCase: 1,
        }],

        "key-spacing": ["error", {
            beforeColon: false,
            afterColon: true,
            mode: "strict",
        }],

        "keyword-spacing": ["error", {
            before: true,
            after: true,
        }],

        "lines-around-comment": ["error", {
            beforeBlockComment: true,
            afterBlockComment: false,
            beforeLineComment: true,
            afterLineComment: false,
            allowBlockStart: true,
            allowBlockEnd: false,
            allowObjectStart: true,
            allowObjectEnd: false,
            allowArrayStart: true,
            allowArrayEnd: false,
        }],

        "max-len": ["error", {
            code: 130,
            comments: 150,
            ignoreComments: false,
            ignoreTrailingComments: false,
            ignoreUrls: true,
        }],

        "max-statements-per-line": ["error", {
            max: 1,
        }],

        "new-cap": ["error"],
        "new-parens": ["error"],
        "no-array-constructor": ["error"],
        "no-bitwise": ["error"],
        "no-continue": ["error"],
        "no-inline-comments": ["error"],
        "no-mixed-operators": ["error"],
        "no-mixed-spaces-and-tabs": ["error"],

        "no-multiple-empty-lines": ["error", {
            max: 1,
            maxEOF: 1,
            maxBOF: 0,
        }],

        "no-negated-condition": ["error"],
        "no-nested-ternary": ["error"],
        "no-new-object": ["error"],
        "no-plusplus": ["error"],
        "no-spaced-func": ["error"],
        "no-trailing-spaces": ["error"],

        "no-underscore-dangle": ["error", {
            allowAfterThis: false,
        }],

        "no-unneeded-ternary": ["error"],
        "no-whitespace-before-property": ["error"],

        "object-curly-newline": ["error", {
            minProperties: 1,
        }],

        "object-curly-spacing": ["error", "always"],
        "object-property-newline": ["error"],
        "one-var": ["error", "never"],
        "operator-assignment": ["error", "always"],
        "operator-linebreak": ["error", "before"],
        "quote-props": ["error", "as-needed"],
        quotes: ["error", "single"],

        semi: ["error", "always"],

        "semi-spacing": ["error", {
            before: false,
            after: true,
        }],

        "space-before-blocks": ["error"],
        "space-before-function-paren": ["error", "never"],
        "space-in-parens": ["error", "never"],
        "space-infix-ops": ["error"],
        "spaced-comment": ["error", "always"],
        "unicode-bom": ["error"],
        "arrow-body-style": ["error", "always"],
        "arrow-parens": ["error", "always"],

        "arrow-spacing": ["error", {
            before: true,
            after: true,
        }],

        "constructor-super": ["error"],

        "generator-star-spacing": ["error", {
            before: true,
            after: false,
        }],

        "no-class-assign": ["error"],
        "no-confusing-arrow": ["error"],
        "no-const-assign": ["error"],
        "no-dupe-class-members": ["error"],
        "no-duplicate-imports": ["error"],
        "no-new-symbol": ["error"],
        "no-this-before-super": ["error"],
        "no-useless-computed-key": ["error"],
        "no-useless-constructor": ["error"],
        "no-useless-rename": ["error"],
        "no-var": ["error"],
        "prefer-const": ["error"],
        "prefer-reflect": ["error"],
        "prefer-spread": ["error"],
        "require-yield": ["error"],
        "rest-spread-spacing": ["error"],
        "template-curly-spacing": ["error", "never"],

        "yield-star-spacing": ["error", {
            before: true,
            after: false,
        }],
    },
}]);